
import React, { useState } from "react";
import axios from "axios";

export default function App() {
  const [resume, setResume] = useState(null);
  const [industry, setIndustry] = useState("");
  const [jobTitle, setJobTitle] = useState("");
  const [jobDescription, setJobDescription] = useState("");
  const [score, setScore] = useState(null);
  const [suggestions, setSuggestions] = useState([]);

  const handleAnalyze = async () => {
    const formData = new FormData();
    formData.append("resume", resume);
    formData.append("industry", industry);
    formData.append("jobTitle", jobTitle);
    formData.append("jobDescription", jobDescription);

    const res = await axios.post(import.meta.env.VITE_API_URL + "/analyze", formData);
    setScore(res.data.score);
    setSuggestions(res.data.suggestions);
  };

  return (
    <div className="p-6 max-w-xl mx-auto space-y-4">
      <h1 className="text-2xl font-bold">ATS Resume Scanner</h1>
      <input type="file" onChange={(e) => setResume(e.target.files[0])} />
      <input placeholder="Industry" value={industry} onChange={(e) => setIndustry(e.target.value)} className="border p-2 w-full" />
      <input placeholder="Job Title" value={jobTitle} onChange={(e) => setJobTitle(e.target.value)} className="border p-2 w-full" />
      <textarea placeholder="Job Description" value={jobDescription} onChange={(e) => setJobDescription(e.target.value)} className="border p-2 w-full" />
      <button onClick={handleAnalyze} className="bg-blue-500 text-white p-2 w-full">Analyze</button>

      {score && (
        <div className="mt-4">
          <p className="font-semibold">Score: {score}%</p>
          <ul className="list-disc list-inside">
            {suggestions.map((s, i) => <li key={i}>{s}</li>)}
          </ul>
        </div>
      )}
    </div>
  );
}
