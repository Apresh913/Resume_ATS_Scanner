
from fastapi import FastAPI, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/analyze")
async def analyze_resume(
    resume: UploadFile,
    industry: str = Form(...),
    jobTitle: str = Form(...),
    jobDescription: str = Form(...)
):
    score = 75
    suggestions = [
        "Include more relevant keywords from job description",
        "Quantify achievements",
        f"Add certifications for the {industry} domain"
    ]
    return JSONResponse(content={"score": score, "suggestions": suggestions})
